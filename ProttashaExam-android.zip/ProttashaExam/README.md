# Prottasha Academy – Android app

Native Android wrapper (WebView) for https://prottashaacademy.com
- Animated splash with the real logo, offline screen with retry
- Camera permission (face attendance) and file upload (OMR / photo) supported
- No external dependencies

## Get the APK with GitHub (no Android Studio needed)
1. Create a new repository on GitHub and upload ALL files of this folder (keep the `.github` folder).
2. Open the repo → **Actions** tab → **Build APK** → **Run workflow** (it also runs on every push).
3. When it finishes (about 3-5 min), open the run → **Artifacts** → download **ProttashaExam-APK** → unzip → `app-debug.apk`.
4. Install on your phone (allow "install unknown apps"). If the old app is installed, uninstall it first (different signing key).

## Change things
- Site address: `SITE` and `HOST` in `app/src/main/java/com/prottasha/exam/MainActivity.java`
- Splash / offline screens: `app/src/main/assets/`
- Extra styling for the site: `app/src/main/assets/theme.css`
