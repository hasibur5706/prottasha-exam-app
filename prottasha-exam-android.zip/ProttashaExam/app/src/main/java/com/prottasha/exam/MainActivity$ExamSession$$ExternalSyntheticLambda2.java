package com.prottasha.exam;

import android.view.View;
import com.prottasha.exam.MainActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda2 implements View.OnClickListener {
    public final /* synthetic */ MainActivity.ExamSession f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda2(MainActivity.ExamSession examSession, String str) {
        this.f$0 = examSession;
        this.f$1 = str;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.ExamSession.m55$r8$lambda$VpxKYt0kCGE45BJRgYHCxqmwo(this.f$0, this.f$1, view);
    }
}
