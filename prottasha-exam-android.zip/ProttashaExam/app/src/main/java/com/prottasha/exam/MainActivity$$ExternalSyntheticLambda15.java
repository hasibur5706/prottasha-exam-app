package com.prottasha.exam;

import android.content.DialogInterface;
import android.widget.EditText;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda15 implements DialogInterface.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ EditText f$2;
    public final /* synthetic */ EditText f$3;
    public final /* synthetic */ EditText f$4;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda15(MainActivity mainActivity, int i, EditText editText, EditText editText2, EditText editText3) {
        this.f$0 = mainActivity;
        this.f$1 = i;
        this.f$2 = editText;
        this.f$3 = editText2;
        this.f$4 = editText3;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        MainActivity.m19$r8$lambda$cs10DC3fvVoonhtamO3lspOEt0(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4, dialogInterface, i);
    }
}
