package com.prottasha.exam;

import com.prottasha.exam.FaceActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class FaceActivity$Bridge$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ FaceActivity.Bridge f$0;

    public /* synthetic */ FaceActivity$Bridge$$ExternalSyntheticLambda2(FaceActivity.Bridge bridge) {
        this.f$0 = bridge;
    }

    @Override // java.lang.Runnable
    public final void run() {
        FaceActivity.Bridge.$r8$lambda$jvlPwYCBQjHH1mx_04PWM0jOigg(this.f$0);
    }
}
