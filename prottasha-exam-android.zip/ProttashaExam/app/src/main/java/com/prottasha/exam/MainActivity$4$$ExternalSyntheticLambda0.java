package com.prottasha.exam;

import com.prottasha.exam.MainActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$4$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ MainActivity.AnonymousClass4 f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$4$$ExternalSyntheticLambda0(MainActivity.AnonymousClass4 anonymousClass4, int i) {
        this.f$0 = anonymousClass4;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.AnonymousClass4.m53$r8$lambda$JAaHTqzE0bf48l2W_drKkmQ_I(this.f$0, this.f$1);
    }
}
