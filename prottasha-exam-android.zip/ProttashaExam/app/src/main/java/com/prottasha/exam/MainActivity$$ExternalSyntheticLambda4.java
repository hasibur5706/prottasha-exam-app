package com.prottasha.exam;

import com.prottasha.exam.MainActivity;
import org.json.JSONArray;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda4 implements MainActivity.Submitter {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ JSONArray f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda4(MainActivity mainActivity, int i, JSONArray jSONArray) {
        this.f$0 = mainActivity;
        this.f$1 = i;
        this.f$2 = jSONArray;
    }

    @Override // com.prottasha.exam.MainActivity.Submitter
    public final void submit(JSONArray jSONArray, Runnable runnable) {
        MainActivity.$r8$lambda$gbbgxHTyCeYasOVpfPS09Vx_rgM(this.f$0, this.f$1, this.f$2, jSONArray, runnable);
    }
}
