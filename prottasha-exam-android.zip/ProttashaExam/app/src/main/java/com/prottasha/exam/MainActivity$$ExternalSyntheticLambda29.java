package com.prottasha.exam;

import android.net.Uri;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda29 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ Uri f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda29(MainActivity mainActivity, Uri uri, int i) {
        this.f$0 = mainActivity;
        this.f$1 = uri;
        this.f$2 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m25$r8$lambda$m3lsu8G5HNpHUYYndr85xWmR9A(this.f$0, this.f$1, this.f$2);
    }
}
