package com.prottasha.exam;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda38 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda38(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$4XHB5HzSgsqCtpmdAofTcbJGFGQ(this.f$0);
    }
}
