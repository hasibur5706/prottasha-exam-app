package com.prottasha.exam;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda61 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda61(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$JyyR3iFiYuA4ToeoNRZ6zn47KJo(this.f$0, view);
    }
}
