package com.prottasha.exam;

import com.prottasha.exam.MainActivity;
import org.json.JSONObject;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda14 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda14(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$DO6I05IqB376oIaWUR6BgC86ZNM(this.f$0, jSONObject);
    }
}
