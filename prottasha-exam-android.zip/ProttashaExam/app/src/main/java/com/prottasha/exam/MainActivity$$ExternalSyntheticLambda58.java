package com.prottasha.exam;

import android.view.View;
import android.widget.CheckBox;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda58 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ CheckBox f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda58(MainActivity mainActivity, CheckBox checkBox) {
        this.f$0 = mainActivity;
        this.f$1 = checkBox;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$7JGreejyIeiVV7BwLVdK2je2WB8(this.f$0, this.f$1, view);
    }
}
