package com.prottasha.exam;

import com.prottasha.exam.FaceActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class FaceActivity$Bridge$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ FaceActivity.Bridge f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ FaceActivity$Bridge$$ExternalSyntheticLambda0(FaceActivity.Bridge bridge, String str) {
        this.f$0 = bridge;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        FaceActivity.Bridge.$r8$lambda$24LmmoeJ3mw1FbiYwfcelWuVVh4(this.f$0, this.f$1);
    }
}
