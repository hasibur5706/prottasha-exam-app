package com.prottasha.exam;

import com.prottasha.exam.Api;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class Api$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ byte[] f$1;
    public final /* synthetic */ String f$2;
    public final /* synthetic */ Api.Callback f$3;

    public /* synthetic */ Api$$ExternalSyntheticLambda3(String str, byte[] bArr, String str2, Api.Callback callback) {
        this.f$0 = str;
        this.f$1 = bArr;
        this.f$2 = str2;
        this.f$3 = callback;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$upload$1(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}
