package com.prottasha.exam;

import android.view.View;
import com.prottasha.exam.MainActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda5 implements View.OnClickListener {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda5(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.ExamSession.$r8$lambda$avDm8t2pdgJxQ6PtYA709Gqundg(this.f$0, view);
    }
}
