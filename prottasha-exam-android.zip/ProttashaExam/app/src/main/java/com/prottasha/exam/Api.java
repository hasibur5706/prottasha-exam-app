package com.prottasha.exam;

import android.os.Handler;
import android.os.Looper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/* loaded from: classes2.dex */
final class Api {
    static Runnable onUnauthorized;
    static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    static String base = "";
    static String token = null;

    /* loaded from: classes2.dex */
    interface Callback {
        void onErr(String str, String str2, int i);

        void onOk(JSONObject jSONObject);
    }

    Api() {
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void call(String str, String str2, JSONObject jSONObject, Callback callback) {
        POOL.execute(new Api$$ExternalSyntheticLambda2(jSONObject, str, str2, callback));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$call$0(JSONObject jSONObject, String str, String str2, Callback callback) {
        byte[] bytes;
        if (jSONObject == null) {
            bytes = null;
        } else {
            try {
                bytes = jSONObject.toString().getBytes("UTF-8");
            } catch (Exception e) {
                networkError(callback);
                return;
            }
        }
        try {
            send(str, str2, bytes, "application/json", callback);
        } catch (Exception e2) {
            networkError(callback);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$networkError$2(Callback callback) {
        callback.onErr("সার্ভারের সাথে সংযোগ হচ্ছে না। ইন্টারনেট ও সার্ভারের ঠিকানা চেক করো।", "NETWORK", 0);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$send$3(Callback callback, JSONObject jSONObject) {
        callback.onOk(jSONObject);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$send$4(boolean z, Callback callback, String str, String str2, int i) {
        if (!z || onUnauthorized == null) {
            callback.onErr(str, str2, i);
        } else {
            onUnauthorized.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$upload$1(String str, byte[] bArr, String str2, Callback callback) {
        try {
            send("POST", str, bArr, str2, callback);
        } catch (Exception e) {
            networkError(callback);
        }
    }

    private static void networkError(Callback callback) {
        MAIN.post(new Api$$ExternalSyntheticLambda4(callback));
    }

    private static String readAll(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[8192];
        while (true) {
            int read = inputStream.read(bArr);
            if (read <= 0) {
                inputStream.close();
                return byteArrayOutputStream.toString("UTF-8");
            }
            byteArrayOutputStream.write(bArr, 0, read);
        }
    }

    private static void send(String str, String str2, byte[] bArr, String str3, Callback callback) throws IOException {
        JSONObject jSONObject;
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(base + "/api" + str2).openConnection();
        httpURLConnection.setConnectTimeout(15000);
        httpURLConnection.setReadTimeout(90000);
        httpURLConnection.setRequestMethod(str);
        httpURLConnection.setRequestProperty("Accept", "application/json");
        if (token != null) {
            httpURLConnection.setRequestProperty("Authorization", "Bearer " + token);
        }
        byte[] bArr2 = (bArr == null && (str.equals("POST") || str.equals("PUT"))) ? new byte[0] : bArr;
        if (bArr2 != null) {
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestProperty("Content-Type", str3);
            httpURLConnection.setFixedLengthStreamingMode(bArr2.length);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            try {
                outputStream.write(bArr2);
            } finally {
                outputStream.close();
            }
        }
        int responseCode = httpURLConnection.getResponseCode();
        InputStream errorStream = responseCode >= 400 ? httpURLConnection.getErrorStream() : httpURLConnection.getInputStream();
        String readAll = errorStream == null ? "" : readAll(errorStream);
        httpURLConnection.disconnect();
        try {
            jSONObject = new JSONObject(readAll);
        } catch (Exception e) {
            jSONObject = new JSONObject();
        }
        JSONObject jSONObject2 = jSONObject;
        if (responseCode >= 200 && responseCode < 300) {
            MAIN.post(new Api$$ExternalSyntheticLambda0(callback, jSONObject2));
            return;
        }
        String optString = jSONObject2.optString("error", "সার্ভারে সমস্যা হয়েছে (" + responseCode + ")");
        MAIN.post(new Api$$ExternalSyntheticLambda1(token != null && (responseCode == 401 || (responseCode == 403 && optString.startsWith("Invalid or expired session"))), callback, optString, (!jSONObject2.has("code") || jSONObject2.isNull("code")) ? null : jSONObject2.optString("code"), responseCode));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void upload(String str, byte[] bArr, String str2, Callback callback) {
        POOL.execute(new Api$$ExternalSyntheticLambda3(str, bArr, str2, callback));
    }
}
