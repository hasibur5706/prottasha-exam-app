package com.prottasha.exam;

import com.prottasha.exam.MainActivity;
import org.json.JSONObject;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda69 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda69(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.$r8$lambda$ghBSQe4aQEnmye8llwJ9O_1Fg3I(this.f$0, jSONObject);
    }
}
