package com.prottasha.exam;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda3(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m8$r8$lambda$GJ8NtPPFwJ6mOwfQwZmXRWJaBc(this.f$0, this.f$1);
    }
}
