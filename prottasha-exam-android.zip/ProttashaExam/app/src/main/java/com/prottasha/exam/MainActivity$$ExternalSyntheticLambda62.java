package com.prottasha.exam;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda62 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda62(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$zgO_gN3t5W85FjtHqs8UPu7hWyA(this.f$0);
    }
}
