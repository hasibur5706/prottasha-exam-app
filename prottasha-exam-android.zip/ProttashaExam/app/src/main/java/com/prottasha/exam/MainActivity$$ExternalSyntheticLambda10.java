package com.prottasha.exam;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda10 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ boolean f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda10(MainActivity mainActivity, boolean z) {
        this.f$0 = mainActivity;
        this.f$1 = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.m4$r8$lambda$632dv2nMGr1zXabSDFH18vfcI(this.f$0, this.f$1, view);
    }
}
