package com.prottasha.exam;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda70 implements View.OnClickListener {
    public final /* synthetic */ Runnable f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda70(Runnable runnable) {
        this.f$0 = runnable;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.lambda$errorPage$5(this.f$0, view);
    }
}
