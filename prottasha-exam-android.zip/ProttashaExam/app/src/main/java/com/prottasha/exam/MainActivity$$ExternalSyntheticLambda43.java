package com.prottasha.exam;

import com.prottasha.exam.MainActivity;
import org.json.JSONArray;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda43 implements MainActivity.Submitter {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda43(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // com.prottasha.exam.MainActivity.Submitter
    public final void submit(JSONArray jSONArray, Runnable runnable) {
        MainActivity.m17$r8$lambda$XKEyic2ZQOEoqtfDd1qRVcjFOY(this.f$0, this.f$1, jSONArray, runnable);
    }
}
