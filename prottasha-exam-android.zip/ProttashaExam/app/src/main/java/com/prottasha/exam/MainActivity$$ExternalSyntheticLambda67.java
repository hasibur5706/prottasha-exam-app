package com.prottasha.exam;

import com.prottasha.exam.MainActivity;
import org.json.JSONObject;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda67 implements MainActivity.Ok {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda67(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // com.prottasha.exam.MainActivity.Ok
    public final void run(JSONObject jSONObject) throws Exception {
        MainActivity.m28$r8$lambda$vz_I9ZY5P7ilFAaEXOGVA5ZjyI(this.f$0, jSONObject);
    }
}
