package com.prottasha.exam;

import com.prottasha.exam.Api;
import org.json.JSONObject;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class Api$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ Api.Callback f$0;
    public final /* synthetic */ JSONObject f$1;

    public /* synthetic */ Api$$ExternalSyntheticLambda0(Api.Callback callback, JSONObject jSONObject) {
        this.f$0 = callback;
        this.f$1 = jSONObject;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$send$3(this.f$0, this.f$1);
    }
}
