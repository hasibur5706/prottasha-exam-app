package com.prottasha.exam;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda2 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda2(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m11$r8$lambda$PHII347s9pSC38oIdmUjWYXl2c(this.f$0);
    }
}
