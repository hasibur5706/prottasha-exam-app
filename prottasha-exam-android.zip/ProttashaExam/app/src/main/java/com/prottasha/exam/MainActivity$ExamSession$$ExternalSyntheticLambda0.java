package com.prottasha.exam;

import com.prottasha.exam.MainActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda0(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.ExamSession.$r8$lambda$TQ4HJs73AYRZ34HRNuMpVHpo_pk(this.f$0);
    }
}
