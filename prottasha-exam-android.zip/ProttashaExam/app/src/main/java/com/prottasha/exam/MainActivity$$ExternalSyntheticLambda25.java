package com.prottasha.exam;

import android.content.DialogInterface;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda25 implements DialogInterface.OnClickListener {
    public final /* synthetic */ MainActivity f$0;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda25(MainActivity mainActivity) {
        this.f$0 = mainActivity;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i) {
        MainActivity.m22$r8$lambda$grqvxgZm8Wux5U3GsP7fGqhZNA(this.f$0, dialogInterface, i);
    }
}
