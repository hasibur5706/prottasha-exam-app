package com.prottasha.exam;

import com.prottasha.exam.Api;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class Api$$ExternalSyntheticLambda4 implements Runnable {
    public final /* synthetic */ Api.Callback f$0;

    public /* synthetic */ Api$$ExternalSyntheticLambda4(Api.Callback callback) {
        this.f$0 = callback;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$networkError$2(this.f$0);
    }
}
