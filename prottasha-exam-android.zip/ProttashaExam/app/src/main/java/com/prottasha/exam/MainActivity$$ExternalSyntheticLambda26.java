package com.prottasha.exam;

import android.view.View;
import android.widget.EditText;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda26 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ EditText f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda26(MainActivity mainActivity, EditText editText) {
        this.f$0 = mainActivity;
        this.f$1 = editText;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$bmOBIZ_aaIgB68UYWe31XriW0HI(this.f$0, this.f$1, view);
    }
}
