package com.prottasha.exam;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda18 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda18(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.$r8$lambda$GDd17EW5TLWPkvDx9qUQ3ld4lhM(this.f$0, this.f$1);
    }
}
