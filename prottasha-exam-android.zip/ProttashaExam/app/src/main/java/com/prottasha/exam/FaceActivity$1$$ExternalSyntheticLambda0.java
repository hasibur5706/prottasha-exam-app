package com.prottasha.exam;

import android.webkit.PermissionRequest;
import com.prottasha.exam.FaceActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class FaceActivity$1$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ PermissionRequest f$0;

    public /* synthetic */ FaceActivity$1$$ExternalSyntheticLambda0(PermissionRequest permissionRequest) {
        this.f$0 = permissionRequest;
    }

    @Override // java.lang.Runnable
    public final void run() {
        FaceActivity.AnonymousClass1.lambda$onPermissionRequest$0(this.f$0);
    }
}
