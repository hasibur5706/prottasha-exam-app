package com.prottasha.exam;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda51 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ boolean f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda51(MainActivity mainActivity, int i, boolean z) {
        this.f$0 = mainActivity;
        this.f$1 = i;
        this.f$2 = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$MHuJ9acgGyk41x2qTtrp6kkTrGw(this.f$0, this.f$1, this.f$2, view);
    }
}
