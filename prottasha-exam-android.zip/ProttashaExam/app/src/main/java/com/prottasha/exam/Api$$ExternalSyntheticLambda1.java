package com.prottasha.exam;

import com.prottasha.exam.Api;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class Api$$ExternalSyntheticLambda1 implements Runnable {
    public final /* synthetic */ boolean f$0;
    public final /* synthetic */ Api.Callback f$1;
    public final /* synthetic */ String f$2;
    public final /* synthetic */ String f$3;
    public final /* synthetic */ int f$4;

    public /* synthetic */ Api$$ExternalSyntheticLambda1(boolean z, Api.Callback callback, String str, String str2, int i) {
        this.f$0 = z;
        this.f$1 = callback;
        this.f$2 = str;
        this.f$3 = str2;
        this.f$4 = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Api.lambda$send$4(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4);
    }
}
