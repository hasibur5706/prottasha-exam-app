package com.prottasha.exam;

import com.prottasha.exam.MainActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda7 implements Runnable {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda7(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.doSubmit();
    }
}
