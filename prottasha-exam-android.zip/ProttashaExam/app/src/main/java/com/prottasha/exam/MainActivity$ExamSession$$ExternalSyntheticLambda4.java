package com.prottasha.exam;

import android.view.View;
import com.prottasha.exam.MainActivity;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$ExamSession$$ExternalSyntheticLambda4 implements View.OnClickListener {
    public final /* synthetic */ MainActivity.ExamSession f$0;

    public /* synthetic */ MainActivity$ExamSession$$ExternalSyntheticLambda4(MainActivity.ExamSession examSession) {
        this.f$0 = examSession;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.ExamSession.m54$r8$lambda$KNCn3zuCcqtPownWtty6VRyz8(this.f$0, view);
    }
}
