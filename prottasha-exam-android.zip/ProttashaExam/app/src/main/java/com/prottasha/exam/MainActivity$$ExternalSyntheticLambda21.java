package com.prottasha.exam;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda21 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ double f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda21(MainActivity mainActivity, double d, int i) {
        this.f$0 = mainActivity;
        this.f$1 = d;
        this.f$2 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$ZgCiawqiwpAD6CpZhGR4SOQRnOk(this.f$0, this.f$1, this.f$2, view);
    }
}
