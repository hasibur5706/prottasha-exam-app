package com.prottasha.exam;

import android.view.View;
import org.json.JSONObject;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda41 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ JSONObject f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda41(MainActivity mainActivity, JSONObject jSONObject) {
        this.f$0 = mainActivity;
        this.f$1 = jSONObject;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$R3nYBJ5Xonc1jWDDT6yaOTV3clU(this.f$0, this.f$1, view);
    }
}
