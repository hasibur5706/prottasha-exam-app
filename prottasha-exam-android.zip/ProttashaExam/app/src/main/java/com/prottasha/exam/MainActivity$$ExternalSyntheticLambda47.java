package com.prottasha.exam;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda47 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda47(MainActivity mainActivity, int i) {
        this.f$0 = mainActivity;
        this.f$1 = i;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$ptoRKQreobGPaEca0trCMcf7IPs(this.f$0, this.f$1, view);
    }
}
