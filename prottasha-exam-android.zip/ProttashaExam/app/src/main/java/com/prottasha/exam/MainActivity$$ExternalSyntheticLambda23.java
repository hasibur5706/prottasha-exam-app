package com.prottasha.exam;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda23 implements Runnable {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda23(MainActivity mainActivity, String str) {
        this.f$0 = mainActivity;
        this.f$1 = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        MainActivity.m15$r8$lambda$VoN2_idDPiHzvSZKKzZhY652OE(this.f$0, this.f$1);
    }
}
