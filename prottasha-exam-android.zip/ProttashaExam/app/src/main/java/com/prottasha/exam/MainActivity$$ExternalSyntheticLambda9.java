package com.prottasha.exam;

import android.view.View;
import android.widget.EditText;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes2.dex */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda9 implements View.OnClickListener {
    public final /* synthetic */ MainActivity f$0;
    public final /* synthetic */ EditText f$1;
    public final /* synthetic */ EditText f$2;
    public final /* synthetic */ EditText f$3;
    public final /* synthetic */ boolean f$4;

    public /* synthetic */ MainActivity$$ExternalSyntheticLambda9(MainActivity mainActivity, EditText editText, EditText editText2, EditText editText3, boolean z) {
        this.f$0 = mainActivity;
        this.f$1 = editText;
        this.f$2 = editText2;
        this.f$3 = editText3;
        this.f$4 = z;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        MainActivity.$r8$lambda$6iRiYq6NpkAe9QLuvTHCBzE8np8(this.f$0, this.f$1, this.f$2, this.f$3, this.f$4, view);
    }
}
