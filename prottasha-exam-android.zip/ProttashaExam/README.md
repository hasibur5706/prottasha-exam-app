# Prottasha Academy (Prottasha Exam) — Android app

A plain Android (Java) app. No extra libraries. This version has the new design:
animated splash with the real logo, a new Home screen, floating bottom bar, rounded cards.

## Get the APK with GitHub (no Android Studio needed)

1. Create a free account at https://github.com and click **New repository** (any name, e.g. `ProttashaExam`).
2. Click **uploading an existing file**, then drag in **everything inside this folder**
   (including the hidden `.github` folder), and click **Commit changes**.
   Tip: if the hidden `.github` folder is missing after upload, upload it separately
   or use GitHub Desktop.
3. Open the **Actions** tab. The **Build APK** workflow starts by itself
   (or click **Build APK**, then **Run workflow**).
4. Wait about 3 to 6 minutes until it shows a green tick.
5. Open that run, scroll to **Artifacts**, and download **ProttashaExam-APK**.
   Unzip it, you get `app-debug.apk`.
6. Copy `app-debug.apk` to your phone and install it
   (allow "install unknown apps" if the phone asks).

## Change the server address

Open `app/build.gradle` and edit this line, then upload again:

    buildConfigField 'String', 'DEFAULT_SERVER_URL', '"https://prottashaacademy.com"'

## Build on your own computer instead

Install Android Studio, open this folder, wait for Gradle sync, then
**Build > Build APK(s)**.

## What changed from the old version

- New animated splash with the real logo
- New Home tab (greeting, current/next exam, quick actions, progress ring, weak topics)
- Floating bottom bar with icons, new colours and rounded cards on every screen
- Login screen with logo
- Same server and same features as before (exams, practice, adaptive, OMR, batches, face, leaderboard)
