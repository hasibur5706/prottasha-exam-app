package com.prottasha.exam;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Tiny JSON-over-HTTP client for the exam server (all calls run off the UI thread). */
final class Api {
    interface Callback {
        void onOk(JSONObject data);
        void onErr(String message, String code, int status);
    }

    static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /** e.g. https://exam.example.com (no trailing slash) */
    static String base = "";
    static String token = null;
    /** Called on the UI thread when the server says the login is no longer valid. */
    static Runnable onUnauthorized;

    static void call(final String method, final String path, final JSONObject body, final Callback cb) {
        POOL.execute(() -> {
            try {
                byte[] data = body == null ? null : body.toString().getBytes("UTF-8");
                send(method, path, data, "application/json", cb);
            } catch (Exception e) {
                networkError(cb);
            }
        });
    }

    static void upload(final String path, final byte[] bytes, final String contentType, final Callback cb) {
        POOL.execute(() -> {
            try {
                send("POST", path, bytes, contentType, cb);
            } catch (Exception e) {
                networkError(cb);
            }
        });
    }

    private static void networkError(final Callback cb) {
        MAIN.post(() -> cb.onErr("সার্ভারের সাথে সংযোগ হচ্ছে না। ইন্টারনেট ও সার্ভারের ঠিকানা চেক করো।", "NETWORK", 0));
    }

    private static void send(String method, String path, byte[] data, String ctype, final Callback cb) throws IOException {
        URL url = new URL(base + "/api" + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(90000);
        c.setRequestMethod(method);
        c.setRequestProperty("Accept", "application/json");
        if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
        if (data == null && (method.equals("POST") || method.equals("PUT"))) data = new byte[0];
        if (data != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", ctype);
            c.setFixedLengthStreamingMode(data.length);
            OutputStream os = c.getOutputStream();
            try { os.write(data); } finally { os.close(); }
        }
        final int status = c.getResponseCode();
        InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = is == null ? "" : readAll(is);
        c.disconnect();

        JSONObject json;
        try { json = new JSONObject(text); } catch (Exception e) { json = new JSONObject(); }
        final JSONObject j = json;

        if (status >= 200 && status < 300) {
            MAIN.post(() -> cb.onOk(j));
            return;
        }
        final String msg = j.optString("error", "সার্ভারে সমস্যা হয়েছে (" + status + ")");
        final String code = j.has("code") && !j.isNull("code") ? j.optString("code") : null;
        final boolean authFail = token != null && (status == 401
                || (status == 403 && msg.startsWith("Invalid or expired session")));
        MAIN.post(() -> {
            if (authFail && onUnauthorized != null) onUnauthorized.run();
            else cb.onErr(msg, code, status);
        });
    }

    private static String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) out.write(buf, 0, n);
        is.close();
        return out.toString("UTF-8");
    }
}
