package com.prottasha.exam;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

/** Thin native shell: shows the hosted exam site in a WebView. */
public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 11;
    private static final int REQ_FILE = 12;

    private WebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingWebPermission;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("exam", MODE_PRIVATE);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String host = Uri.parse(serverUrl()).getHost();
                Uri u = r.getUrl();
                if (host != null && host.equalsIgnoreCase(u.getHost())) return false;
                String scheme = u.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) return false; // fonts/CDNs load as subresources; links stay in-app
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showOffline();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(req.getResources());
                    } else {
                        pendingWebPermission = req;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                    }
                });
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (b != null) web.restoreState(b);
        else load();
    }

    private String serverUrl() {
        String u = prefs.getString("server", BuildConfig.DEFAULT_SERVER_URL);
        return u == null ? "" : u;
    }

    private void load() {
        String u = serverUrl();
        if (u.isEmpty()) askServer(); else web.loadUrl(u);
    }

    private void askServer() {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        in.setHint("https://your-exam-site.com");
        in.setText(serverUrl());
        new AlertDialog.Builder(this)
            .setTitle("Server address")
            .setMessage("Enter the web address where the exam system is hosted.")
            .setView(in)
            .setCancelable(!serverUrl().isEmpty())
            .setPositiveButton("Connect", (d, w) -> {
                String u = in.getText().toString().trim();
                if (u.isEmpty()) { Toast.makeText(this, "Address required", Toast.LENGTH_SHORT).show(); askServer(); return; }
                if (!u.matches("^https?://.*")) u = "https://" + u;
                while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
                prefs.edit().putString("server", u).apply();
                web.loadUrl(u);
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showOffline() {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
            + "<body style='font-family:sans-serif;text-align:center;padding:12vh 24px;color:#1e1b4b'>"
            + "<h2>Can't connect</h2><p>Check your internet connection and the server address.</p>"
            + "<p><button style='font-size:18px;padding:12px 24px' onclick='Android.retry()'>Retry</button></p>"
            + "<p><button style='font-size:16px;padding:10px 20px' onclick='Android.changeServer()'>Change server address</button></p>"
            + "</body></html>";
        web.loadDataWithBaseURL("https://app.local/", html, "text/html", "utf-8", null);
    }

    private class Bridge {
        @JavascriptInterface public void retry() { runOnUiThread(MainActivity.this::load); }
        @JavascriptInterface public void changeServer() { runOnUiThread(MainActivity.this::askServer); }
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_CAMERA && pendingWebPermission != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) pendingWebPermission.grant(pendingWebPermission.getResources());
            else pendingWebPermission.deny();
            pendingWebPermission = null;
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && filePathCallback != null) {
            filePathCallback.onReceiveValue(android.webkit.WebChromeClient.FileChooserParams.parseResult(res, data));
            filePathCallback = null;
        }
    }

    @Override public boolean onKeyDown(int key, KeyEvent e) {
        if (key == KeyEvent.KEYCODE_BACK && web.canGoBack()) { web.goBack(); return true; }
        return super.onKeyDown(key, e);
    }

    @Override protected void onSaveInstanceState(Bundle b) { super.onSaveInstanceState(b); web.saveState(b); }
}
