package com.prottasha.exam;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Prottasha Academy – native student app. Talks to the exam server's JSON API. */
public class MainActivity extends Activity {
    private static final int REQ_CAM = 21, REQ_PICK = 22, REQ_FACE = 23, REQ_CAM_PERM = 24;
    private static final String[][] TABS = {
            {"exams", "📝", "পরীক্ষা"}, {"practice", "🧠", "প্র্যাকটিস"}, {"dash", "📊", "ড্যাশবোর্ড"},
            {"batches", "🎓", "ব্যাচ"}, {"more", "☰", "আরও"}};

    /** True when the server address is built into the app: no address screen, no way to change it. */
    private static final boolean FIXED_SERVER = !BuildConfig.DEFAULT_SERVER_URL.isEmpty();

    private interface Ok { void run(JSONObject d) throws Exception; }
    private interface Submitter { void submit(JSONArray answers, Runnable onFail); }

    private SharedPreferences prefs;
    private LinearLayout nav, header;
    private FrameLayout content;
    private TextView titleView, backBtn;
    private TextView[] navItems = new TextView[TABS.length];
    private Runnable onBack, refreshAction;
    private String tab = "exams";
    private int screenToken = 0;
    private CountDownTimer timer;
    private AlertDialog busyDialog;

    private int pendingOmrExam;
    private Uri camUri;
    private Runnable afterFace;

    // ------------------------------------------------------------------ small helpers
    private int dp(float v) { return Ui.dp(this, v); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private static JSONObject json(Object... kv) {
        JSONObject o = new JSONObject();
        try { for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]); } catch (Exception ignored) { }
        return o;
    }
    private static JSONArray arr(JSONObject o, String k) {
        JSONArray a = o.optJSONArray(k);
        return a == null ? new JSONArray() : a;
    }
    private static JSONObject at(JSONArray a, int i) {
        JSONObject o = a.optJSONObject(i);
        return o == null ? new JSONObject() : o;
    }
    private static String str(JSONObject o, String k) {
        return o.isNull(k) ? "" : o.optString(k, "");
    }
    private static String num(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.2f", v);
    }
    private static String when(String s) {
        return s == null ? "" : s.replace('T', ' ');
    }
    private static String fmtUtc(String s) {
        try {
            String t = s.replace(' ', 'T');
            if (t.length() > 19) t = t.substring(0, 19);
            SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = in.parse(t);
            return new SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(d);
        } catch (Exception e) {
            return s;
        }
    }

    private void showError(String msg) {
        hideBusy();
        new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("ঠিক আছে", null).show();
    }
    private void confirm(String title, String msg, final Runnable yes) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg)
                .setPositiveButton("হ্যাঁ", (d, w) -> yes.run())
                .setNegativeButton("না", null).show();
    }
    private void busy(String msg) {
        hideBusy();
        busyDialog = new AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show();
    }
    private void hideBusy() {
        if (busyDialog != null) { try { busyDialog.dismiss(); } catch (Exception ignored) { } busyDialog = null; }
    }

    /** Callback for button actions: hides the busy dialog and shows errors in a dialog. */
    private Api.Callback actCb(final Ok ok) {
        return new Api.Callback() {
            @Override public void onOk(JSONObject d) {
                hideBusy();
                try { ok.run(d); } catch (Exception e) { showError("সমস্যা হয়েছে: " + e.getMessage()); }
            }
            @Override public void onErr(String m, String c, int s) { showError(m); }
        };
    }

    /** Callback for loading a screen: ignores late replies, shows a retry page on failure. */
    private Api.Callback pageCb(final Ok ok, final Runnable retry) {
        final int tok = screenToken;
        return new Api.Callback() {
            @Override public void onOk(JSONObject d) {
                if (tok != screenToken) return;
                try { ok.run(d); } catch (Exception e) { errorPage("দেখাতে সমস্যা হয়েছে: " + e.getMessage(), retry); }
            }
            @Override public void onErr(String m, String c, int s) {
                if (tok != screenToken) return;
                errorPage(m, retry);
            }
        };
    }

    // ------------------------------------------------------------------ chrome / navigation
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("exam", MODE_PRIVATE);
        Api.base = FIXED_SERVER ? BuildConfig.DEFAULT_SERVER_URL : prefs.getString("server", BuildConfig.DEFAULT_SERVER_URL);
        Api.token = prefs.getString("token", null);
        Api.onUnauthorized = () -> { clearLogin(); toast("আবার লগইন করো।"); route(); };
        buildChrome();
        route();
    }

    private void buildChrome() {
        LinearLayout root = Ui.vbox(this);
        root.setBackgroundColor(Ui.BG);

        header = Ui.hbox(this);
        header.setBackgroundColor(Ui.INDIGO);
        header.setPadding(dp(8), dp(10), dp(8), dp(10));
        backBtn = Ui.tv(this, "←", 22, Ui.WHITE, true);
        backBtn.setPadding(dp(10), dp(2), dp(14), dp(2));
        backBtn.setOnClickListener(v -> onBackPressed());
        header.addView(backBtn);
        titleView = Ui.tv(this, "Prottasha Academy", 18, Ui.WHITE, true);
        header.addView(titleView, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        TextView refresh = Ui.tv(this, "↻", 24, Ui.WHITE, true);
        refresh.setPadding(dp(12), dp(2), dp(12), dp(2));
        refresh.setOnClickListener(v -> { if (refreshAction != null) refreshAction.run(); });
        header.addView(refresh);
        root.addView(header, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

        nav = Ui.hbox(this);
        nav.setBackgroundColor(Ui.WHITE);
        for (int i = 0; i < TABS.length; i++) {
            final String key = TABS[i][0];
            TextView t = Ui.tv(this, TABS[i][1] + "\n" + TABS[i][2], 11, Ui.MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(7), 0, dp(7));
            t.setOnClickListener(v -> showMain(key));
            navItems[i] = t;
            nav.addView(t, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
        }
        root.addView(nav, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        setContentView(root);
    }

    private void setScreen(String title, View v, boolean showNav, Runnable back, Runnable refresh) {
        screenToken++;
        stopTimer();
        titleView.setText(title);
        onBack = back;
        refreshAction = refresh;
        backBtn.setVisibility(back != null ? View.VISIBLE : View.GONE);
        header.setVisibility(View.VISIBLE);
        nav.setVisibility(showNav ? View.VISIBLE : View.GONE);
        setContent(v);
    }

    private void setContent(View v) {
        content.removeAllViews();
        content.addView(v, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
    }

    private View centered(String msg) {
        FrameLayout f = new FrameLayout(this);
        TextView t = Ui.tv(this, msg, 16, Ui.MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(24), dp(24), dp(24), dp(24));
        f.addView(t, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        return f;
    }

    private LinearLayout pageBox() {
        LinearLayout l = Ui.vbox(this);
        l.setPadding(dp(14), dp(14), dp(14), dp(24));
        return l;
    }

    private void setPage(LinearLayout box) {
        ScrollView sv = new ScrollView(this);
        sv.addView(box, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        setContent(sv);
    }

    private void errorPage(String msg, final Runnable retry) {
        LinearLayout box = pageBox();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(24), dp(60), dp(24), dp(24));
        TextView t = Ui.tv(this, msg, 16, Ui.RED, false);
        t.setGravity(Gravity.CENTER);
        Ui.add(box, t, 16);
        if (retry != null) Ui.add(box, Ui.primary(this, "আবার চেষ্টা করো", v -> retry.run()));
        setPage(box);
    }

    private void stopTimer() {
        if (timer != null) { timer.cancel(); timer = null; }
    }

    @Override
    public void onBackPressed() {
        if (onBack != null) onBack.run();
        else super.onBackPressed();
    }

    // ------------------------------------------------------------------ session
    private void saveLogin(JSONObject d) {
        JSONObject u = d.optJSONObject("user");
        if (u == null) u = new JSONObject();
        Api.token = d.optString("token");
        prefs.edit().putString("token", Api.token).putInt("uid", u.optInt("id"))
                .putString("name", u.optString("name")).putString("email", u.optString("email"))
                .putString("role", u.optString("role")).apply();
    }

    private void clearLogin() {
        Api.token = null;
        prefs.edit().remove("token").remove("uid").remove("name").remove("email").remove("role").apply();
    }

    private void route() {
        if (Api.base == null || Api.base.isEmpty()) showServerSetup(false);
        else if (Api.token == null) showAuth(false);
        else if ("admin".equals(prefs.getString("role", ""))) showAdminNote();
        else showMain(tab);
    }

    // ------------------------------------------------------------------ server setup + auth
    private void showServerSetup(final boolean cancellable) {
        LinearLayout box = pageBox();
        box.setPadding(dp(20), dp(40), dp(20), dp(20));
        Ui.add(box, Ui.tv(this, "সার্ভারের ঠিকানা", 22, Ui.INK, true), 8);
        Ui.add(box, Ui.tv(this, "যে ওয়েবসাইটে পরীক্ষা সিস্টেম চালু আছে তার ঠিকানা দাও। যেমন: https://exam.example.com", 14, Ui.MUTED, false), 16);
        final android.widget.EditText in = Ui.input(this, "https://your-site.com",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        in.setText(Api.base == null ? "" : Api.base);
        Ui.add(box, in, 14);
        Ui.add(box, Ui.primary(this, "সংযোগ করো", v -> {
            String u = in.getText().toString().trim();
            if (u.isEmpty()) { showError("ঠিকানা লেখো।"); return; }
            if (!u.matches("(?i)^https?://.*")) u = "https://" + u;
            while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
            final String url = u;
            final String old = Api.base;
            busy("সংযোগ পরীক্ষা হচ্ছে…");
            Api.base = url;
            Api.call("GET", "/public/home", null, new Api.Callback() {
                @Override public void onOk(JSONObject d) {
                    hideBusy();
                    if (!url.equals(old)) clearLogin();
                    prefs.edit().putString("server", url).apply();
                    route();
                }
                @Override public void onErr(String m, String c, int s) {
                    Api.base = old;
                    showError("এই ঠিকানায় পরীক্ষা সার্ভার পাওয়া যায়নি।\n" + m);
                }
            });
        }), 10);
        setScreen("সার্ভার", scroll(box), false, cancellable ? () -> showMain("more") : null, null);
    }

    private ScrollView scroll(View v) {
        ScrollView sv = new ScrollView(this);
        sv.addView(v, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        return sv;
    }

    private void showAuth(final boolean register) {
        LinearLayout box = pageBox();
        box.setPadding(dp(20), dp(30), dp(20), dp(20));
        Ui.add(box, Ui.tv(this, register ? "নতুন অ্যাকাউন্ট" : "লগইন", 24, Ui.INK, true), 4);
        Ui.add(box, Ui.tv(this, "Prottasha Academy", 14, Ui.MUTED, false), 18);
        final android.widget.EditText name = Ui.input(this, "তোমার নাম",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        final android.widget.EditText email = Ui.input(this, "ইমেইল",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        final android.widget.EditText pass = Ui.input(this, "পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        if (register) Ui.add(box, name, 10);
        Ui.add(box, email, 10);
        Ui.add(box, pass, 14);
        Ui.add(box, Ui.primary(this, register ? "অ্যাকাউন্ট খোলো" : "লগইন করো", v -> {
            String e = email.getText().toString().trim(), p = pass.getText().toString(), n = name.getText().toString().trim();
            if (e.isEmpty() || p.isEmpty() || (register && n.isEmpty())) { showError("সব ঘর পূরণ করো।"); return; }
            busy("অপেক্ষা করো…");
            Api.call("POST", register ? "/auth/register" : "/auth/login",
                    register ? json("name", n, "email", e, "password", p) : json("email", e, "password", p),
                    actCb(d -> { saveLogin(d); tab = "exams"; route(); }));
        }), 10);
        Ui.add(box, Ui.secondary(this, register ? "আগে থেকেই অ্যাকাউন্ট আছে? লগইন" : "নতুন? অ্যাকাউন্ট খোলো",
                v -> showAuth(!register)), 10);
        if (!FIXED_SERVER) Ui.add(box, Ui.btn(this, "সার্ভারের ঠিকানা: " + Api.base, Ui.WHITE, Ui.MUTED, v -> showServerSetup(false)), 10);
        setScreen("Prottasha Academy", scroll(box), false, null, null);
    }

    private void showAdminNote() {
        LinearLayout box = pageBox();
        box.setPadding(dp(20), dp(40), dp(20), dp(20));
        Ui.add(box, Ui.tv(this, "অ্যাডমিন অ্যাকাউন্ট", 22, Ui.INK, true), 8);
        Ui.add(box, Ui.tv(this, "এই অ্যাপ শিক্ষার্থীদের জন্য। অ্যাডমিন প্যানেল ব্রাউজারে খোলো।", 15, Ui.MUTED, false), 16);
        Ui.add(box, Ui.primary(this, "অ্যাডমিন প্যানেল খোলো", v ->
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Api.base + "/admin")))), 10);
        Ui.add(box, Ui.secondary(this, "লগআউট", v -> { clearLogin(); route(); }), 10);
        setScreen("অ্যাডমিন", scroll(box), false, null, null);
    }

    // ------------------------------------------------------------------ main tabs
    private void showMain(final String t) {
        tab = t;
        for (int i = 0; i < TABS.length; i++) navItems[i].setTextColor(TABS[i][0].equals(t) ? Ui.INDIGO : Ui.MUTED);
        String title = "Prottasha Academy";
        for (String[] x : TABS) if (x[0].equals(t)) title = x[2];
        setScreen(title, centered("লোড হচ্ছে…"), true, null, () -> showMain(t));
        final Runnable retry = () -> showMain(t);
        switch (t) {
            case "exams": loadExams(retry); break;
            case "practice": loadPractice(retry); break;
            case "dash": loadDashboard(retry); break;
            case "batches": loadBatches(retry); break;
            default: showMore(); break;
        }
    }

    // ---- exams
    private void loadExams(Runnable retry) {
        Api.call("GET", "/online/exams", null, pageCb(d -> {
            LinearLayout box = pageBox();
            JSONArray list = arr(d, "exams");
            if (list.length() == 0) {
                Ui.add(box, Ui.tv(this, "এখন কোনো পরীক্ষা নেই। 'ব্যাচ' ট্যাব থেকে ব্যাচে যোগ দাও।", 15, Ui.MUTED, false));
            }
            for (int i = 0; i < list.length(); i++) Ui.add(box, examCard(at(list, i)), 12);
            setPage(box);
        }, retry));
    }

    private View examCard(final JSONObject e) {
        final int id = e.optInt("id");
        final String state = e.optString("state"), mode = e.optString("mode", "online"), choice = str(e, "choice");
        LinearLayout c = Ui.card(this);
        Ui.add(c, Ui.tv(this, e.optString("title"), 17, Ui.INK, true), 4);
        String meta = e.optInt("questions") + " টি প্রশ্ন · " + Math.max(1, e.optInt("time_limit_seconds") / 60) + " মিনিট · "
                + ("omr".equals(mode) ? "OMR" : "both".equals(mode) ? "অনলাইন বা OMR" : "অনলাইন");
        if (!str(e, "batch_name").isEmpty()) meta += "\n" + e.optString("batch_name");
        if (!str(e, "end_time").isEmpty()) meta += "\nশেষ সময়: " + when(e.optString("end_time"));
        Ui.add(c, Ui.tv(this, meta, 13, Ui.MUTED, false), 8);

        switch (state) {
            case "open":
                if ("online".equals(mode) || "online".equals(choice)) {
                    Ui.add(c, Ui.primary(this, "পরীক্ষা শুরু করো", v -> confirm("পরীক্ষা শুরু করবে?",
                            "শুরু করলে সময় চলতে থাকবে।", () -> startLive(id))), 0);
                } else {
                    if ("both".equals(mode)) {
                        Ui.add(c, Ui.tv(this, "একবার বেছে নিলে আর বদলানো যাবে না।", 12, Ui.AMBER, false), 6);
                        Ui.add(c, Ui.primary(this, "অনলাইনে দেবো", v -> confirm("অনলাইনে পরীক্ষা দেবে?",
                                "এই পরীক্ষা অনলাইনেই দিতে হবে, OMR-এ নয়।", () -> startLive(id))), 6);
                    }
                    Ui.add(c, Ui.secondary(this, "OMR-এ দেবো", v -> confirm("OMR-এ পরীক্ষা দেবে?",
                            "উত্তর কাগজের OMR শিটে দিয়ে ছবি তুলে জমা দিতে হবে।", () -> chooseOmr(id))), 0);
                }
                break;
            case "in_progress":
                Ui.add(c, Ui.tv(this, "পরীক্ষা চলছে — বাকি " + clock(e.optInt("remaining_seconds")), 13, Ui.AMBER, true), 6);
                Ui.add(c, Ui.primary(this, "চালিয়ে যাও", v -> startLive(id)), 0);
                break;
            case "omr": {
                String sub = str(e, "omr_submission");
                String status = "published".equals(sub) ? "ফলাফল প্রকাশিত"
                        : "uploaded".equals(sub) ? "OMR শিট জমা হয়েছে — স্ক্যানের অপেক্ষায়"
                        : "error".equals(sub) ? "শিটে সমস্যা পাওয়া গেছে — আবার ছবি তুলে জমা দাও"
                        : "তুমি OMR-এ পরীক্ষা দিচ্ছো। উত্তর OMR শিটে দিয়ে ছবি জমা দাও।";
                Ui.add(c, Ui.tv(this, status, 13, Ui.INDIGO, true), 8);
                Ui.add(c, Ui.secondary(this, "প্রশ্নপত্র দেখো", v -> showPaper(id)), 6);
                if (!"published".equals(sub)) {
                    Ui.add(c, Ui.primary(this, "📷 OMR শিটের ছবি জমা দাও", v -> pickOmrImage(id)), 0);
                }
                break;
            }
            case "done": {
                JSONObject r = e.optJSONObject("result");
                if (r != null) {
                    Ui.add(c, Ui.tv(this, "✅ নম্বর: " + num(r.optDouble("marks")) + " / " + num(r.optDouble("max_marks"))
                            + "\nসঠিক " + r.optInt("right") + " · ভুল " + r.optInt("wrong") + " · বাদ " + r.optInt("skipped")
                            + "\nর‍্যাঙ্ক: " + r.optInt("rank") + " / " + r.optInt("participants"), 14, Ui.GREEN, true), 8);
                    final boolean omr = "published".equals(str(e, "omr_submission"));
                    final int rid = r.optInt("result_id");
                    Ui.add(c, Ui.secondary(this, "উত্তর ও ব্যাখ্যা দেখো", v -> openReview(rid, omr)), 0);
                } else {
                    Ui.add(c, Ui.tv(this, e.optBoolean("result_hidden") ? str(e, "result_note")
                            : "তোমার উত্তর জমা হয়েছে।", 13, Ui.INDIGO, true), 0);
                }
                break;
            }
            case "upcoming":
                Ui.add(c, Ui.tv(this, "⏳ এখনো শুরু হয়নি" + (str(e, "start_time").isEmpty() ? "" : " — শুরু: " + when(e.optString("start_time"))), 13, Ui.AMBER, true), 0);
                break;
            case "locked":
                Ui.add(c, Ui.tv(this, "🔒 এই পরীক্ষা তোমার ব্যাচের নয়।", 13, Ui.MUTED, false), 6);
                Ui.add(c, Ui.secondary(this, "ব্যাচে যোগ দাও", v -> showMain("batches")), 0);
                break;
            case "closed": Ui.add(c, Ui.tv(this, "সময়সীমা শেষ।", 13, Ui.MUTED, true), 0); break;
            case "expired": Ui.add(c, Ui.tv(this, "সময় শেষ হয়ে গেছে, উত্তর জমা হয়নি।", 13, Ui.RED, true), 0); break;
            default: Ui.add(c, Ui.tv(this, "এখনও প্রশ্ন যোগ করা হয়নি।", 13, Ui.MUTED, false), 0); break;
        }
        return c;
    }

    private String clock(int sec) {
        sec = Math.max(0, sec);
        int h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, s) : String.format(Locale.US, "%02d:%02d", m, s);
    }

    private void chooseOmr(final int id) {
        busy("অপেক্ষা করো…");
        Api.call("POST", "/online/exams/" + id + "/choose", json("mode", "omr"), actCb(d -> showMain("exams")));
    }

    private void startLive(final int id) {
        busy("পরীক্ষা লোড হচ্ছে…");
        Api.call("POST", "/online/exams/" + id + "/start", null, new Api.Callback() {
            @Override public void onOk(JSONObject d) { hideBusy(); openLive(d); }
            @Override public void onErr(String m, String code, int s) {
                hideBusy();
                if ("FACE_REQUIRED".equals(code)) startFace("verify", id, () -> startLive(id));
                else showError(m);
            }
        });
    }

    private void openLive(JSONObject d) {
        final int examId = d.optInt("exam_id");
        new ExamSession(d.optString("title"), arr(d, "questions"), d.optInt("remaining_seconds", -1),
                (answers, onFail) -> Api.call("POST", "/online/exams/" + examId + "/submit", json("answers", answers),
                        new Api.Callback() {
                            @Override public void onOk(JSONObject r) {
                                hideBusy();
                                if (r.optBoolean("result_hidden")) showReceipt(r.optString("message"));
                                else showResult("ফলাফল", r, arr(r, "results"));
                            }
                            @Override public void onErr(String m, String c, int s) { onFail.run(); showError(m); }
                        })).show();
    }

    private void showReceipt(String msg) {
        LinearLayout box = pageBox();
        box.setPadding(dp(20), dp(50), dp(20), dp(20));
        Ui.add(box, Ui.tv(this, "✅ জমা হয়েছে", 22, Ui.GREEN, true), 10);
        Ui.add(box, Ui.tv(this, msg, 15, Ui.INK, false), 18);
        Ui.add(box, Ui.primary(this, "পরীক্ষার তালিকায় ফিরে যাও", v -> showMain("exams")), 0);
        setScreen("জমা", scroll(box), false, () -> showMain("exams"), null);
    }

    private void showPaper(int id) {
        busy("প্রশ্নপত্র লোড হচ্ছে…");
        Api.call("GET", "/online/exams/" + id + "/paper", null, actCb(d -> {
            LinearLayout box = pageBox();
            JSONArray qs = arr(d, "questions");
            for (int i = 0; i < qs.length(); i++) {
                JSONObject q = at(qs, i), o = q.optJSONObject("options");
                if (o == null) o = new JSONObject();
                LinearLayout c = Ui.card(this);
                Ui.add(c, Ui.tv(this, q.optInt("no") + ". " + q.optString("question"), 16, Ui.INK, true), 6);
                for (String k : new String[]{"a", "b", "c", "d"})
                    Ui.add(c, Ui.tv(this, k.toUpperCase() + ".  " + o.optString(k), 15, Ui.INK, false), 3);
                Ui.add(box, c, 10);
            }
            final String back = tab;
            setScreen(d.optString("title", "প্রশ্নপত্র"), scroll(box), false, () -> showMain(back), null);
        }));
    }

    private void openReview(int resultId, boolean omr) {
        busy("লোড হচ্ছে…");
        if (!omr) {
            Api.call("GET", "/online/results/" + resultId + "/review", null,
                    actCb(d -> showResult("ফলাফল", d, arr(d, "results"))));
        } else {
            Api.call("GET", "/omr/results/" + resultId + "/review", null, actCb(d -> {
                JSONArray in = arr(d, "answers"), out = new JSONArray();
                String[] L = {"a", "b", "c", "d"};
                for (int i = 0; i < in.length(); i++) {
                    JSONObject a = at(in, i);
                    int sel = a.isNull("selected_option") ? 0 : a.optInt("selected_option"), cor = a.optInt("correct_option");
                    out.put(json("question_text", a.optString("question"),
                            "options", json("a", a.optString("option1"), "b", a.optString("option2"),
                                    "c", a.optString("option3"), "d", a.optString("option4")),
                            "your_answer", sel >= 1 && sel <= 4 ? L[sel - 1] : JSONObject.NULL,
                            "correct_answer", cor >= 1 && cor <= 4 ? L[cor - 1] : "",
                            "is_correct", sel == cor && sel != 0, "explanation", ""));
                }
                showResult("ফলাফল", new JSONObject(), out);
            }));
        }
    }

    // ---- result + review screen
    private void showResult(String title, JSONObject sum, JSONArray rows) {
        LinearLayout box = pageBox();
        LinearLayout s = Ui.card(this);
        if (sum.has("marks")) {
            Ui.add(s, Ui.tv(this, "নম্বর: " + num(sum.optDouble("marks")) + " / " + num(sum.optDouble("max_marks")), 24, Ui.INDIGO, true), 6);
            Ui.add(s, Ui.tv(this, "স্কোর " + sum.optInt("score") + "%  ·  র‍্যাঙ্ক " + sum.optInt("rank") + " / " + sum.optInt("participants"), 15, Ui.INK, true), 4);
            Ui.add(s, Ui.tv(this, "সঠিক " + sum.optInt("correct_count") + " · ভুল " + sum.optInt("wrong_count")
                    + " · বাদ " + sum.optInt("skipped_count"), 14, Ui.MUTED, false), 0);
        } else if (sum.has("score")) {
            Ui.add(s, Ui.tv(this, "স্কোর: " + sum.optInt("score") + "%", 26, Ui.INDIGO, true), 6);
            Ui.add(s, Ui.tv(this, "সঠিক " + sum.optInt("correct_count") + " / " + sum.optInt("total_questions"), 15, Ui.INK, true), 4);
            if (!str(sum, "message").isEmpty()) Ui.add(s, Ui.tv(this, sum.optString("message"), 13, Ui.MUTED, false), 0);
        } else {
            Ui.add(s, Ui.tv(this, "উত্তর পর্যালোচনা", 18, Ui.INDIGO, true), 0);
        }
        Ui.add(box, s, 14);

        for (int i = 0; i < rows.length(); i++) {
            JSONObject r = at(rows, i), o = r.optJSONObject("options");
            if (o == null) o = new JSONObject();
            String your = str(r, "your_answer"), right = str(r, "correct_answer");
            LinearLayout c = Ui.card(this);
            Ui.add(c, Ui.tv(this, (i + 1) + ". " + r.optString("question_text"), 16, Ui.INK, true), 8);
            for (String k : new String[]{"a", "b", "c", "d"}) {
                TextView t = Ui.tv(this, k.toUpperCase() + ".  " + o.optString(k, ""), 15, Ui.INK, false);
                t.setPadding(dp(10), dp(8), dp(10), dp(8));
                if (k.equalsIgnoreCase(right)) t.setBackground(Ui.box(this, Ui.GREEN_BG, Ui.GREEN, 8));
                else if (k.equalsIgnoreCase(your)) t.setBackground(Ui.box(this, Ui.RED_BG, Ui.RED, 8));
                else t.setBackground(Ui.box(this, Ui.WHITE, Ui.LINE, 8));
                Ui.add(c, t, 5);
            }
            if (your.isEmpty()) Ui.add(c, Ui.tv(this, "উত্তর দাওনি", 13, Ui.AMBER, true), 4);
            else Ui.add(c, Ui.tv(this, r.optBoolean("is_correct") ? "✅ সঠিক" : "❌ ভুল — সঠিক উত্তর: " + right.toUpperCase(), 13,
                    r.optBoolean("is_correct") ? Ui.GREEN : Ui.RED, true), 4);
            if (!str(r, "explanation").isEmpty())
                Ui.add(c, Ui.tv(this, "ব্যাখ্যা: " + r.optString("explanation"), 13, Ui.MUTED, false), 0);
            Ui.add(box, c, 10);
        }
        Ui.add(box, Ui.primary(this, "শেষ", v -> showMain(tab)), 0);
        setScreen(title, scroll(box), false, () -> showMain(tab), null);
    }

    // ---- taking an exam (live or practice)
    private class ExamSession {
        final String title;
        final JSONArray qs;
        final int remaining;
        final Submitter submitter;
        final int n;
        final String[] sel;
        final long[] spent;
        int idx = 0;
        long shown = System.currentTimeMillis();
        boolean busy = false;
        TextView timerView, progressView;
        LinearLayout body;
        ScrollView sv;
        android.widget.Button prev, next, send;

        ExamSession(String title, JSONArray qs, int remaining, Submitter submitter) {
            this.title = title; this.qs = qs; this.remaining = remaining; this.submitter = submitter;
            n = qs.length();
            sel = new String[n];
            spent = new long[n];
        }

        void show() {
            LinearLayout screen = Ui.vbox(MainActivity.this);

            LinearLayout top = Ui.hbox(MainActivity.this);
            top.setBackgroundColor(Ui.SOFT);
            top.setPadding(dp(14), dp(8), dp(14), dp(8));
            progressView = Ui.tv(MainActivity.this, "", 14, Ui.INK, true);
            top.addView(progressView, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
            timerView = Ui.tv(MainActivity.this, remaining >= 0 ? "⏱ " + clock(remaining) : "", 16, Ui.INDIGO, true);
            top.addView(timerView);
            screen.addView(top, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));

            sv = new ScrollView(MainActivity.this);
            body = Ui.vbox(MainActivity.this);
            body.setPadding(dp(14), dp(14), dp(14), dp(14));
            sv.addView(body, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
            screen.addView(sv, new LinearLayout.LayoutParams(Ui.MATCH, 0, 1));

            LinearLayout bottom = Ui.vbox(MainActivity.this);
            bottom.setBackgroundColor(Ui.WHITE);
            bottom.setPadding(dp(12), dp(8), dp(12), dp(8));
            LinearLayout row = Ui.hbox(MainActivity.this);
            prev = Ui.secondary(MainActivity.this, "← আগের", v -> go(idx - 1));
            next = Ui.secondary(MainActivity.this, "পরের →", v -> go(idx + 1));
            LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
            lp1.rightMargin = dp(6);
            LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, Ui.WRAP, 1);
            lp2.leftMargin = dp(6);
            row.addView(prev, lp1);
            row.addView(next, lp2);
            Ui.add(bottom, row, 8);
            send = Ui.primary(MainActivity.this, "উত্তর জমা দাও", v -> askSubmit());
            Ui.add(bottom, send, 0);
            screen.addView(bottom, new LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP));

            setScreen(title, screen, false, () -> confirm("পরীক্ষা থেকে বের হবে?",
                    remaining >= 0 ? "উত্তর জমা হবে না। পরে আবার এসে বাকি সময় থেকে চালিয়ে যেতে পারবে।"
                            : "এই প্র্যাকটিসের উত্তর হারিয়ে যাবে।", () -> showMain(tab)), null);
            renderQ();

            if (remaining >= 0) {
                timer = new CountDownTimer(remaining * 1000L, 1000) {
                    @Override public void onTick(long ms) {
                        int s = (int) (ms / 1000);
                        timerView.setText("⏱ " + clock(s));
                        timerView.setTextColor(s < 60 ? Ui.RED : Ui.INDIGO);
                    }
                    @Override public void onFinish() {
                        timerView.setText("⏱ 00:00");
                        doSubmit();
                    }
                }.start();
            }
        }

        void leave() {
            spent[idx] += (System.currentTimeMillis() - shown) / 1000;
        }

        void go(int to) {
            if (to < 0 || to >= n) return;
            leave();
            idx = to;
            shown = System.currentTimeMillis();
            renderQ();
            sv.scrollTo(0, 0);
        }

        void renderQ() {
            int answered = 0;
            for (String s : sel) if (s != null) answered++;
            progressView.setText("প্রশ্ন " + (idx + 1) + " / " + n + "  ·  উত্তর " + answered);
            prev.setEnabled(idx > 0);
            next.setEnabled(idx < n - 1);
            body.removeAllViews();
            JSONObject q = at(qs, idx);
            if (!str(q, "topic_name").isEmpty()) Ui.add(body, Ui.tv(MainActivity.this, q.optString("topic_name"), 12, Ui.MUTED, true), 4);
            Ui.add(body, Ui.tv(MainActivity.this, q.optString("question_text"), 18, Ui.INK, true), 14);
            for (final String k : new String[]{"a", "b", "c", "d"}) {
                boolean on = k.equals(sel[idx]);
                TextView t = Ui.tv(MainActivity.this, k.toUpperCase() + ".   " + q.optString("option_" + k), 16, Ui.INK, on);
                t.setPadding(dp(14), dp(14), dp(14), dp(14));
                t.setBackground(on ? Ui.box(MainActivity.this, Ui.SOFT, Ui.INDIGO, 12) : Ui.box(MainActivity.this, Ui.WHITE, Ui.LINE, 12));
                t.setOnClickListener(v -> { sel[idx] = k.equals(sel[idx]) ? null : k; renderQ(); });
                Ui.add(body, t, 10);
            }
        }

        void askSubmit() {
            if (busy) return;
            int blank = 0;
            for (String s : sel) if (s == null) blank++;
            confirm("উত্তর জমা দেবে?", blank > 0 ? blank + " টি প্রশ্নের উত্তর দাওনি। তবুও জমা দেবে?" : "সব প্রশ্নের উত্তর দেওয়া হয়েছে।",
                    this::doSubmit);
        }

        void doSubmit() {
            if (busy) return;
            busy = true;
            leave();
            shown = System.currentTimeMillis();
            JSONArray answers = new JSONArray();
            for (int i = 0; i < n; i++) {
                answers.put(json("question_id", at(qs, i).optInt("id"),
                        "selected_option", sel[i] == null ? JSONObject.NULL : sel[i],
                        "time_taken_seconds", spent[i]));
            }
            MainActivity.this.busy("জমা হচ্ছে…");
            submitter.submit(answers, () -> { busy = false; });
        }
    }

    // ---- practice tab
    private void loadPractice(Runnable retry) {
        Api.call("GET", "/exam/practice-exams", null, pageCb(d -> {
            LinearLayout box = pageBox();
            LinearLayout intro = Ui.card(this);
            Ui.add(intro, Ui.tv(this, "প্র্যাকটিস করো", 17, Ui.INK, true), 4);
            Ui.add(intro, Ui.tv(this, "তোমার ব্যাচের শেষ হওয়া পরীক্ষার প্রশ্ন থেকে অনুশীলন। ৫টি পরীক্ষা দিলে দুর্বল জায়গার উপর Adaptive Exam পাবে।", 13, Ui.MUTED, false), 10);
            Ui.add(intro, Ui.primary(this, "র‍্যান্ডম প্র্যাকটিস (১০টি প্রশ্ন)", v -> {
                busy("প্রশ্ন তৈরি হচ্ছে…");
                Api.call("POST", "/exam/generate", json("count", 10), actCb(this::openPractice));
            }), 8);
            Ui.add(intro, Ui.secondary(this, "🧠 Adaptive Exam (দুর্বল জায়গা)", v -> {
                busy("তোমার জন্য প্রশ্ন তৈরি হচ্ছে… একটু সময় লাগতে পারে।");
                Api.call("POST", "/exam/generate-adaptive", null, actCb(this::openPractice));
            }), 0);
            Ui.add(box, intro, 14);

            JSONArray list = arr(d, "exams");
            for (int i = 0; i < list.length(); i++) {
                final JSONObject e = at(list, i);
                LinearLayout c = Ui.card(this);
                Ui.add(c, Ui.tv(this, e.optString("title"), 16, Ui.INK, true), 3);
                Ui.add(c, Ui.tv(this, e.optInt("questions") + " টি প্রশ্ন · " + str(e, "batch_name")
                        + (e.optBoolean("participated") ? " · ✅ পরীক্ষা দিয়েছো" : ""), 13, Ui.MUTED, false), 8);
                if (e.optBoolean("practice_open")) {
                    Ui.add(c, Ui.secondary(this, "এই পরীক্ষা প্র্যাকটিস করো", v -> {
                        busy("প্রশ্ন তৈরি হচ্ছে…");
                        Api.call("POST", "/exam/generate", json("panel_exam_id", e.optInt("id")), actCb(this::openPractice));
                    }), 0);
                } else {
                    Ui.add(c, Ui.tv(this, "পরীক্ষা শেষ হলে প্র্যাকটিস খুলবে।", 12, Ui.AMBER, false), 0);
                }
                Ui.add(box, c, 10);
            }
            setPage(box);
        }, retry));
    }

    private void openPractice(JSONObject d) {
        final JSONArray qs = arr(d, "questions");
        if (qs.length() == 0) {
            showError(str(d, "message").isEmpty() ? "এখন কোনো প্রশ্ন পাওয়া যায়নি।" : d.optString("message"));
            return;
        }
        final int examId = d.optInt("exam_id");
        new ExamSession(str(d, "message").isEmpty() ? "প্র্যাকটিস" : "প্র্যাকটিস", qs, -1,
                (answers, onFail) -> Api.call("POST", "/exam/" + examId + "/submit", json("answers", answers),
                        new Api.Callback() {
                            @Override public void onOk(JSONObject r) {
                                hideBusy();
                                JSONArray in = arr(r, "results"), out = new JSONArray();
                                for (int i = 0; i < in.length(); i++) {
                                    JSONObject row = at(in, i), q = null;
                                    for (int j = 0; j < qs.length(); j++)
                                        if (at(qs, j).optInt("id") == row.optInt("question_id")) q = at(qs, j);
                                    if (q != null) {
                                        try {
                                            row.put("options", json("a", q.optString("option_a"), "b", q.optString("option_b"),
                                                    "c", q.optString("option_c"), "d", q.optString("option_d")));
                                        } catch (Exception ignored) { }
                                    }
                                    out.put(row);
                                }
                                showResult("প্র্যাকটিসের ফলাফল", r, out);
                            }
                            @Override public void onErr(String m, String c, int s) { onFail.run(); showError(m); }
                        })).show();
    }

    // ---- dashboard
    private void loadDashboard(Runnable retry) {
        Api.call("GET", "/exam/performance", null, pageCb(d -> {
            LinearLayout box = pageBox();
            LinearLayout top = Ui.card(this);
            Ui.add(top, Ui.tv(this, "তোমার অগ্রগতি", 17, Ui.INK, true), 6);
            Ui.add(top, Ui.tv(this, "পরীক্ষা দিয়েছো: " + d.optInt("exams_completed"), 15, Ui.INDIGO, true), 4);
            Ui.add(top, Ui.tv(this, d.optBoolean("adaptive_ready") ? "🧠 Adaptive Exam প্রস্তুত — 'প্র্যাকটিস' ট্যাবে যাও।"
                    : "Adaptive Exam পেতে আরও " + d.optInt("exams_needed") + " টি পরীক্ষা দাও।", 13, Ui.MUTED, false), 0);
            Ui.add(box, top, 14);

            JSONArray list = arr(d, "topic_performance");
            if (list.length() == 0) Ui.add(box, Ui.tv(this, "এখনও কোনো ফলাফল নেই। পরীক্ষা দিলে এখানে দেখা যাবে।", 14, Ui.MUTED, false));
            for (int i = 0; i < list.length(); i++) {
                JSONObject p = at(list, i);
                String level = p.optString("level");
                int col = "strong".equals(level) ? Ui.GREEN : "weak".equals(level) ? Ui.RED : Ui.AMBER;
                String lbl = "strong".equals(level) ? "ভালো" : "weak".equals(level) ? "দুর্বল" : "উন্নতি দরকার";
                LinearLayout c = Ui.card(this);
                Ui.add(c, Ui.tv(this, p.optString("topic_name"), 15, Ui.INK, true), 2);
                Ui.add(c, Ui.tv(this, "সঠিক " + p.optInt("correct_count") + " / " + p.optInt("total_attempts")
                        + " · " + Math.round(p.optDouble("accuracy") * 100) + "% · " + lbl, 13, col, true), 8);
                Ui.add(c, Ui.bar(this, p.optDouble("accuracy"), col), 0);
                Ui.add(box, c, 10);
            }
            setPage(box);
        }, retry));
    }

    // ---- batches
    private void loadBatches(Runnable retry) {
        Api.call("GET", "/omr/batches", null, pageCb(d -> {
            LinearLayout box = pageBox();
            JSONArray list = arr(d, "batches");
            if (list.length() == 0) Ui.add(box, Ui.tv(this, "এখনও কোনো ব্যাচ নেই।", 15, Ui.MUTED, false));
            for (int i = 0; i < list.length(); i++) {
                final JSONObject b = at(list, i);
                final int id = b.optInt("id");
                final double price = b.optDouble("price");
                String state = b.optString("state");
                LinearLayout c = Ui.card(this);
                Ui.add(c, Ui.tv(this, b.optString("name"), 17, Ui.INK, true), 3);
                Ui.add(c, Ui.tv(this, b.optInt("exams") + " টি পরীক্ষা · " + (price > 0 ? "৳" + num(price) : "ফ্রি"), 13, Ui.MUTED, false), 8);
                if ("active".equals(state)) {
                    Ui.add(c, Ui.tv(this, "✅ তুমি এই ব্যাচে আছো", 14, Ui.GREEN, true), 4);
                    JSONArray ex = arr(b, "exam_list");
                    for (int j = 0; j < ex.length(); j++)
                        Ui.add(c, Ui.tv(this, "• " + at(ex, j).optString("title"), 13, Ui.INK, false), 2);
                } else if ("pending".equals(state)) {
                    Ui.add(c, Ui.tv(this, "⏳ পেমেন্ট অ্যাডমিনের অনুমোদনের অপেক্ষায় আছে।", 13, Ui.AMBER, true), 0);
                } else {
                    if ("rejected".equals(state)) Ui.add(c, Ui.tv(this, "আগের পেমেন্ট গ্রহণ করা হয়নি। আবার চেষ্টা করো।", 13, Ui.RED, true), 6);
                    Ui.add(c, Ui.primary(this, price > 0 ? "যোগ দাও (পেমেন্ট)" : "যোগ দাও", v -> {
                        if (price > 0) paymentDialog(id);
                        else {
                            busy("অপেক্ষা করো…");
                            Api.call("POST", "/omr/batches/" + id + "/join", new JSONObject(),
                                    actCb(r -> { toast(r.optString("message", "যুক্ত হয়েছো")); showMain("batches"); }));
                        }
                    }), 0);
                }
                Ui.add(box, c, 12);
            }
            setPage(box);
        }, retry));
    }

    private void paymentDialog(final int batchId) {
        LinearLayout f = Ui.vbox(this);
        f.setPadding(dp(18), dp(10), dp(18), dp(0));
        final android.widget.EditText method = Ui.input(this, "পেমেন্ট মাধ্যম (bKash / Nagad…)", InputType.TYPE_CLASS_TEXT);
        final android.widget.EditText sender = Ui.input(this, "যে নম্বর থেকে পাঠিয়েছো", InputType.TYPE_CLASS_PHONE);
        final android.widget.EditText trx = Ui.input(this, "Transaction ID", InputType.TYPE_CLASS_TEXT);
        Ui.add(f, method, 8);
        Ui.add(f, sender, 8);
        Ui.add(f, trx, 8);
        new AlertDialog.Builder(this).setTitle("পেমেন্টের তথ্য").setView(f)
                .setPositiveButton("জমা দাও", (dlg, w) -> {
                    busy("অপেক্ষা করো…");
                    Api.call("POST", "/omr/batches/" + batchId + "/join",
                            json("method", method.getText().toString(), "sender_number", sender.getText().toString(),
                                    "transaction_id", trx.getText().toString()),
                            actCb(r -> { toast(r.optString("message", "জমা হয়েছে")); showMain("batches"); }));
                }).setNegativeButton("বাতিল", null).show();
    }

    // ---- more
    private void showMore() {
        LinearLayout box = pageBox();
        LinearLayout me = Ui.card(this);
        Ui.add(me, Ui.tv(this, prefs.getString("name", ""), 18, Ui.INK, true), 2);
        Ui.add(me, Ui.tv(this, prefs.getString("email", ""), 13, Ui.MUTED, false), 0);
        Ui.add(box, me, 14);
        Ui.add(box, Ui.secondary(this, "🏆 লিডারবোর্ড", v -> showLeaderboard()), 10);
        Ui.add(box, Ui.secondary(this, "📷 ফেস হাজিরা (পার্সোনাল কেয়ার)", v -> showFace()), 10);
        if (!FIXED_SERVER) Ui.add(box, Ui.btn(this, "🌐 সার্ভারের ঠিকানা বদলাও", Ui.WHITE, Ui.INK, v -> confirm("সার্ভার বদলাবে?",
                "ঠিকানা বদলালে তোমাকে আবার লগইন করতে হবে।", () -> showServerSetup(true))), 10);
        Ui.add(box, Ui.btn(this, "লগআউট", Ui.RED_BG, Ui.RED, v -> confirm("লগআউট করবে?", "", () -> {
            clearLogin();
            route();
        })), 10);
        if (!FIXED_SERVER) Ui.add(box, Ui.tv(this, "সার্ভার: " + Api.base, 12, Ui.MUTED, false), 0);
        setPage(box);
    }

    private void showLeaderboard() {
        setScreen("লিডারবোর্ড", centered("লোড হচ্ছে…"), false, () -> showMain("more"), this::showLeaderboard);
        Api.call("GET", "/exam/leaderboard", null, pageCb(d -> {
            LinearLayout box = pageBox();
            JSONArray list = arr(d, "leaderboard");
            int me = prefs.getInt("uid", -1);
            if (list.length() == 0) Ui.add(box, Ui.tv(this, "এখনও কেউ লিডারবোর্ডে নেই (কমপক্ষে ৩টি প্র্যাকটিস exam লাগে)।", 14, Ui.MUTED, false));
            for (int i = 0; i < list.length(); i++) {
                JSONObject r = at(list, i);
                boolean mine = r.optInt("student_id") == me;
                LinearLayout row = Ui.hbox(this);
                row.setPadding(dp(14), dp(12), dp(14), dp(12));
                row.setBackground(Ui.box(this, mine ? Ui.SOFT : Ui.WHITE, mine ? Ui.INDIGO : Ui.LINE, 12));
                String medal = i == 0 ? "🥇" : i == 1 ? "🥈" : i == 2 ? "🥉" : String.valueOf(i + 1);
                TextView rank = Ui.tv(this, medal, 18, Ui.INK, true);
                rank.setMinWidth(dp(40));
                row.addView(rank);
                LinearLayout mid = Ui.vbox(this);
                mid.addView(Ui.tv(this, r.optString("name"), 15, Ui.INK, true));
                mid.addView(Ui.tv(this, r.optInt("exams_completed") + " টি পরীক্ষা", 12, Ui.MUTED, false));
                row.addView(mid, new LinearLayout.LayoutParams(0, Ui.WRAP, 1));
                row.addView(Ui.tv(this, num(r.optDouble("avg_score")) + "%", 17, Ui.INDIGO, true));
                Ui.add(box, row, 8);
            }
            setPage(box);
        }, this::showLeaderboard));
    }

    // ---- face attendance
    private void showFace() {
        setScreen("ফেস হাজিরা", centered("লোড হচ্ছে…"), false, () -> showMain("more"), this::showFace);
        Api.call("GET", "/face/me", null, pageCb(d -> {
            LinearLayout box = pageBox();
            final boolean enrolled = d.optBoolean("enrolled");
            final boolean approved = enrolled && "approved".equals(d.optString("status"));
            LinearLayout c = Ui.card(this);
            Ui.add(c, Ui.tv(this, !enrolled ? "তুমি এখনও পার্সোনাল কেয়ারে যুক্ত নও।"
                    : approved ? "✅ তুমি পার্সোনাল কেয়ারে যুক্ত আছো।"
                    : "⏳ আবেদন জমা হয়েছে — অ্যাডমিনের অনুমোদনের অপেক্ষায়।", 15, Ui.INK, true), 8);
            String photo = str(d, "photo");
            if (photo.contains(",")) {
                try {
                    byte[] bytes = Base64.decode(photo.substring(photo.indexOf(',') + 1), Base64.DEFAULT);
                    ImageView iv = new ImageView(this);
                    iv.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length));
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(96), dp(96));
                    lp.bottomMargin = dp(10);
                    c.addView(iv, lp);
                } catch (Exception ignored) { }
            }
            if (!enrolled) {
                final CheckBox cb = new CheckBox(this);
                cb.setText("আমি ফেস ডেটা সংরক্ষণে সম্মতি দিচ্ছি।");
                cb.setTextColor(Ui.INK);
                Ui.add(c, cb, 8);
                Ui.add(c, Ui.primary(this, "ক্যামেরায় যুক্ত হও", v -> {
                    if (!cb.isChecked()) { showError("আগে সম্মতির বক্সে টিক দাও।"); return; }
                    startFace("enroll", 0, this::showFace);
                }), 0);
            } else {
                if (approved) Ui.add(c, Ui.primary(this, "📷 হাজিরা দাও", v -> startFace("verify", 0, this::showFace)), 8);
                Ui.add(c, Ui.btn(this, "পার্সোনাল কেয়ার ছেড়ে দাও", Ui.RED_BG, Ui.RED, v -> confirm("ছেড়ে দেবে?",
                        "তোমার ছবি ও ফেস ডেটা মুছে যাবে।", () -> {
                            busy("অপেক্ষা করো…");
                            Api.call("DELETE", "/face/me", null, actCb(r -> showFace()));
                        })), 0);
            }
            Ui.add(box, c, 14);
            JSONArray recent = arr(d, "recent");
            if (recent.length() > 0) Ui.add(box, Ui.tv(this, "সাম্প্রতিক হাজিরা", 15, Ui.INK, true), 8);
            for (int i = 0; i < recent.length(); i++) {
                JSONObject r = at(recent, i);
                Ui.add(box, Ui.tv(this, ("exam".equals(r.optString("kind")) ? "📝 " + str(r, "title") : "🏫 হাজিরা")
                        + " — " + fmtUtc(r.optString("marked_at")), 13, Ui.MUTED, false), 4);
            }
            setPage(box);
        }, this::showFace));
    }

    private void startFace(String mode, int examId, Runnable after) {
        afterFace = after;
        Intent i = new Intent(this, FaceActivity.class);
        i.putExtra("mode", mode);
        i.putExtra("exam_id", examId);
        startActivityForResult(i, REQ_FACE);
    }

    // ---- OMR photo upload
    private void pickOmrImage(int examId) {
        pendingOmrExam = examId;
        new AlertDialog.Builder(this).setTitle("OMR শিটের ছবি")
                .setItems(new String[]{"📷 ক্যামেরায় ছবি তোলো", "🖼 গ্যালারি থেকে নাও"}, (d, which) -> {
                    if (which == 0) {
                        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchCamera();
                        else requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM_PERM);
                    } else {
                        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                        i.setType("image/*");
                        startActivityForResult(Intent.createChooser(i, "ছবি বেছে নাও"), REQ_PICK);
                    }
                }).show();
    }

    private void launchCamera() {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "omr_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProttashaOMR");
            camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
            startActivityForResult(i, REQ_CAM);
        } catch (Exception e) {
            showError("ক্যামেরা খোলা যায়নি। গ্যালারি থেকে ছবি নাও।");
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_CAM_PERM) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else showError("ক্যামেরার অনুমতি দাও, অথবা গ্যালারি থেকে ছবি নাও।");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAM) {
            if (res == RESULT_OK && camUri != null) uploadOmr(camUri);
            else if (camUri != null) { try { getContentResolver().delete(camUri, null, null); } catch (Exception ignored) { } }
        } else if (req == REQ_PICK) {
            if (res == RESULT_OK && data != null && data.getData() != null) uploadOmr(data.getData());
        } else if (req == REQ_FACE) {
            String msg = data == null ? "" : data.getStringExtra("message");
            if (res == RESULT_OK) {
                if (msg != null && !msg.isEmpty()) toast(msg);
                if (afterFace != null) afterFace.run();
            } else if (msg != null && !msg.isEmpty()) {
                showError(msg);
            }
        }
    }

    private void uploadOmr(final Uri uri) {
        final int exam = pendingOmrExam;
        busy("ছবি আপলোড হচ্ছে…");
        Api.POOL.execute(() -> {
            byte[] jpg;
            try {
                jpg = compress(uri);
            } catch (Exception e) {
                runOnUiThread(() -> showError("ছবিটি পড়া যায়নি। আবার চেষ্টা করো।"));
                return;
            }
            Api.upload("/omr/exams/" + exam + "/submission", jpg, "image/jpeg", actCb(d -> {
                toast(d.optString("message", "OMR শিট জমা হয়েছে।"));
                showMain("exams");
            }));
        });
    }

    /** Reads the photo, fixes rotation, shrinks to at most 2400px and encodes it as JPEG (server limit is 8 MB). */
    private byte[] compress(Uri uri) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream is = getContentResolver().openInputStream(uri);
        BitmapFactory.decodeStream(is, null, o);
        is.close();
        int sample = 1, max = Math.max(o.outWidth, o.outHeight);
        while (max / sample > 3200) sample *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = sample;
        is = getContentResolver().openInputStream(uri);
        Bitmap bmp = BitmapFactory.decodeStream(is, null, o);
        is.close();
        if (bmp == null) throw new Exception("decode failed");

        int rot = 0;
        try {
            InputStream is2 = getContentResolver().openInputStream(uri);
            int ori = new ExifInterface(is2).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            is2.close();
            if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
            else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
            else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
        } catch (Exception ignored) { }
        float scale = Math.min(1f, 2400f / Math.max(bmp.getWidth(), bmp.getHeight()));
        if (rot != 0 || scale < 1f) {
            Matrix m = new Matrix();
            if (rot != 0) m.postRotate(rot);
            if (scale < 1f) m.postScale(scale, scale);
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
        }
        int q = 88;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, q, out);
        while (out.size() > 7 * 1024 * 1024 && q > 40) {
            q -= 15;
            out.reset();
            bmp.compress(Bitmap.CompressFormat.JPEG, q, out);
        }
        return out.toByteArray();
    }
}
