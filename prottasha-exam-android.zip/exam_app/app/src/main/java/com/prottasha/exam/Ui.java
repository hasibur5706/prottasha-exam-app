package com.prottasha.exam;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small helpers to build the screens in code. */
final class Ui {
    static final int INDIGO = 0xFF4338CA, SOFT = 0xFFEEF0FF, BG = 0xFFF4F4FB, INK = 0xFF1E1B4B,
            MUTED = 0xFF6B7280, GREEN = 0xFF16A34A, RED = 0xFFDC2626, AMBER = 0xFFD97706,
            WHITE = 0xFFFFFFFF, LINE = 0xFFD9DCEC, GREEN_BG = 0xFFE8F8EE, RED_BG = 0xFFFDECEC;

    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable box(Context c, int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(dp(c, 1.5f), stroke);
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static Button btn(Context c, String label, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(box(c, bg, bg == WHITE ? LINE : 0, 12));
        b.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        b.setMinHeight(0);
        b.setMinimumHeight(dp(c, 44));
        b.setOnClickListener(l);
        return b;
    }

    static Button primary(Context c, String label, View.OnClickListener l) {
        return btn(c, label, INDIGO, WHITE, l);
    }

    static Button secondary(Context c, String label, View.OnClickListener l) {
        return btn(c, label, SOFT, INDIGO, l);
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(box(c, WHITE, LINE, 14));
        l.setPadding(dp(c, 14), dp(c, 14), dp(c, 14), dp(c, 14));
        return l;
    }

    /** Adds [v] to [parent] with a small gap underneath. */
    static void add(ViewGroup parent, View v) {
        add(parent, v, 10);
    }

    static void add(ViewGroup parent, View v, int bottomDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.bottomMargin = dp(parent.getContext(), bottomDp);
        parent.addView(v, lp);
    }

    static EditText input(Context c, String hint, int inputType) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(INK);
        e.setHintTextColor(MUTED);
        e.setBackground(box(c, WHITE, LINE, 10));
        e.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
        return e;
    }

    /** A thin horizontal bar filled to [frac] (0..1). */
    static View bar(Context c, double frac, int color) {
        LinearLayout track = new LinearLayout(c);
        track.setBackground(box(c, 0xFFE5E7EB, 0, 6));
        View fill = new View(c);
        fill.setBackground(box(c, color, 0, 6));
        float f = (float) Math.max(0.02, Math.min(1, frac));
        track.addView(fill, new LinearLayout.LayoutParams(0, dp(c, 10), f));
        track.addView(new View(c), new LinearLayout.LayoutParams(0, dp(c, 10), 1 - f));
        return track;
    }

    static int color(String hex) {
        return Color.parseColor(hex);
    }
}
