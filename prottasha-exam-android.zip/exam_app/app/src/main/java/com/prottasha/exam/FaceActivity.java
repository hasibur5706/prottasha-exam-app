package com.prottasha.exam;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Camera face scan. Uses the same face engine as the website so faces match what the server stores. */
public class FaceActivity extends Activity {
    private WebView web;
    private boolean finished = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> req.grant(req.getResources()));
            }
        });
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            start();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) start();
        else finishWith(RESULT_CANCELED, "ক্যামেরার অনুমতি দেওয়া হয়নি।");
    }

    private void start() {
        try {
            InputStream is = getAssets().open("face.html");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) out.write(buf, 0, n);
            is.close();
            // https base URL makes the page a secure origin, which the camera requires
            web.loadDataWithBaseURL("https://face.local/", out.toString("UTF-8"), "text/html", "utf-8", null);
        } catch (Exception e) {
            finishWith(RESULT_CANCELED, "ফেস স্ক্রিন খোলা যায়নি।");
        }
    }

    private void finishWith(int result, String message) {
        if (finished) return;
        finished = true;
        Intent i = new Intent();
        i.putExtra("message", message);
        setResult(result, i);
        finish();
    }

    private class Bridge {
        @JavascriptInterface
        public String config() {
            try {
                JSONObject o = new JSONObject();
                o.put("base", Api.base);
                o.put("token", Api.token == null ? "" : Api.token);
                o.put("mode", getIntent().getStringExtra("mode"));
                o.put("examId", getIntent().getIntExtra("exam_id", 0));
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void done(final String msg) { runOnUiThread(() -> finishWith(RESULT_OK, msg)); }

        @JavascriptInterface
        public void fail(final String msg) { runOnUiThread(() -> finishWith(RESULT_CANCELED, msg)); }

        @JavascriptInterface
        public void cancel() { runOnUiThread(() -> finishWith(RESULT_CANCELED, "")); }
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.loadUrl("about:blank"); web.destroy(); }
        super.onDestroy();
    }
}
