# Prottasha Academy – Android app

A native Android shell (WebView) around the hosted exam system. Camera (face check) and photo upload (OMR) work.

## Build the APK
**Option A – GitHub (no setup):** push this folder to a GitHub repo → Actions tab → "Build APK" → download `ProttashaExam-apk` → `app-debug.apk`.

**Option B – Android Studio:** open this folder, wait for Gradle sync, Build → Build APK(s).

**Option C – command line:** JDK 17 + Android SDK (platform 34), then `gradle assembleDebug`.

## Server address
The app needs the exam server running somewhere reachable (Node + MySQL, from your zip).
- Leave `DEFAULT_SERVER_URL` empty in `app/build.gradle` and the app asks for the address on first launch (changeable from the error screen), or
- set it there, e.g. `'"https://exam.example.com"'`.
Use an https address — browsers/WebViews only allow the camera on secure origins.

## Play Store
The debug APK installs directly on phones. For the Play Store you need a signed release build (`assembleRelease` + your keystore).
