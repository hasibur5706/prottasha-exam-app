# Prottasha Academy – native Android app

Native Kotlin-free Java app (no web view for the main screens). It talks to your exam server's JSON API.

Screens: login/register · exams (online + OMR) · timed exam · results & answer review · practice & adaptive exam ·
dashboard · leaderboard · batches (free join / payment info) · OMR sheet photo upload (camera or gallery) · face attendance.

The face scan uses the same face engine as the website (loaded from the internet), so faces match what the server stores.

## Server
Needs your exam server online (https). On first launch the app asks for its address; to bake it in, set
`DEFAULT_SERVER_URL` in `app/build.gradle`, e.g. `'"https://exam.example.com"'`.

## Build
GitHub Actions (see the workflow in the repo) or Android Studio → Build APK. Requires Android 10+ (minSdk 29).
